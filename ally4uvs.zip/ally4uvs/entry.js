import * as vscode from 'vscode';
import { responderAgent } from './agents/responder';
import { correctionAgent } from './agents/correction';
import { reminderAgent } from './agents/reminder';
import { addToChatContext } from './utils/context';
import { generateAltSuggestion } from './agents/altgen';

export function activate(context: vscode.ExtensionContext) {
  context.subscriptions.push(
    vscode.commands.registerCommand('codea11y.runAgents', async () => {
      const prompt = await vscode.window.showInputBox({ prompt: 'Ask CodeA11y something...' });
      if (!prompt) return;
      // Check for alt text generation intent
      if (/suggest an alt text/i.test(prompt) && /(http[s]?:\/\/.*\.(?:png|jpg|jpeg|webp|gif|svg))/i.test(prompt)) {
        const imageUrl = prompt.match(/(http[s]?:\/\/.*\.(?:png|jpg|jpeg|webp|gif|svg))/i)?.[0];
        if (imageUrl) {
          const { altSuggestion, reminderNote } = await generateAltSuggestion(imageUrl, ''); // pass current alt if needed
          vscode.window.showInformationMessage(`Suggestion: ${altSuggestion}`);
          vscode.window.showInformationMessage(`Reminder: ${reminderNote}`);
          return;
        }
      
      // Step 1: Responder Agent
      const responderReply = await responderAgent(prompt);
      vscode.window.showInformationMessage(`Responder: ${responderReply}`);

      // Step 2: Correction Agent
      const correctionReply = await correctionAgent();
      vscode.window.showInformationMessage(`Correction: ${correctionReply}`);

      // Step 3: Reminder Agent
      const reminderReply = await reminderAgent();
      vscode.window.showInformationMessage(`Reminder: ${reminderReply}`);

      // Store in chat context
      addToChatContext(prompt, responderReply);
    })
  );
}
