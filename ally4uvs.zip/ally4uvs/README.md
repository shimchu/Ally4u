# Ally4uVS

**Ally4uVS** is a Visual Studio Code extension prototype designed to enhance coding accessibility and productivity. It leverages AI-powered agents to assist with intelligent code suggestions, accessibility checks, and automated fixes—making coding easier and more inclusive.

## Agents

- **Responder Agent**  
  Provides context-aware code completions and intelligent suggestions to help you write code faster and more accurately.

- **Corrector Agent**  
  Analyzes your code for accessibility issues and offers actionable recommendations to improve code quality and inclusiveness.

- **Reminder Agent**  
  Extends GitHub Copilot functionality by adding custom commands and workflows, helping you stay organized and efficient while coding.

## How to Use

1. Install the extension in Visual Studio Code.
2. Open your project or any code file.
3. Open the Command Palette (`Ctrl+Shift+P` or `Cmd+Shift+P`).
4. Type the name of the agent or command you want to use and select it.
5. Follow the prompts or review the suggestions provided.

## Demo

A demo video showcasing the key features and usage of this extension is included with this submission.

## Requirements

- Visual Studio Code version 1.60.0 or later  
- Node.js (if applicable for extension development or runtime)

## Extension Settings

Currently, Ally4uVS does not require any user configuration.

## Known Issues

- [List any known issues or limitations here. For example:]  
  - Some accessibility checks may generate false positives.  
  - Reminder agent commands are limited in scope for the prototype phase.

## Author

Dharm

## License

[MIT License](https://opensource.org/licenses/MIT)
