"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateAltSuggestion = generateAltSuggestion;
const openai_1 = require("openai");
const openai = new openai_1.OpenAI({ apiKey: 'YOUR_KEY' });
function generateAltSuggestion(imageUrl, currentAlt) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const systemPrompt = `
You are an accessibility expert.
Given an image and its current alt text, decide:
1. Whether the alt text accurately describes the image
2. If not, generate a better one
3. Do NOT assume whether the image is decorative — just assume it's instrumental
4. Output ONLY the suggested alt text.
`;
        const userPrompt = `
Image URL: ${imageUrl}
Current alt text: "${currentAlt}"

Instructions: Suggest an improved alt text assuming the image is instrumental.
`;
        const response = yield openai.chat.completions.create({
            model: 'gpt-4o',
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userPrompt }
            ],
            temperature: 0.2,
        });
        const suggestion = ((_b = (_a = response.choices[0]) === null || _a === void 0 ? void 0 : _a.message.content) === null || _b === void 0 ? void 0 : _b.trim()) || "No suggestion";
        const reminder = `This is the suggested alt text assuming the image is instrumental to the webpage. 
If it is decorative — leave alt empty. 
Decorative images should also have role="presentation" or aria-hidden="true" and are used purely for layout, 
like borders, spacers, or background embellishments. 
The page is still understandable if the element is removed.`;
        return {
            altSuggestion: suggestion,
            reminderNote: reminder,
        };
    });
}
