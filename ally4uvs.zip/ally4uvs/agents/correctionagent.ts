import { callLLM } from '../utils/api';
import { getAccessibilityLogs, getRelevantCodeContext } from '../utils/context';

export async function correctionAgent(): Promise<string> {
  const logs = await getAccessibilityLogs();
  const code = await getRelevantCodeContext();

  const systemPrompt = `
You are the Correction Agent in CodeA11y.
Use Axe Linter logs and code to identify unresolved accessibility issues.
Suggest specific code changes or fixes to the developer.
  `.trim();

  const fullPrompt = `
[Accessibility Logs]
${logs}

[Relevant Code]
${code}
  `.trim();

  return await callLLM(systemPrompt, fullPrompt);
}
