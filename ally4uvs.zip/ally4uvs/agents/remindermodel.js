"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.reminderAgent = reminderAgent;
const api_1 = require("../utils/api");
const context_1 = require("../utils/context");
const notifier_1 = require("../utils/notifier");
function reminderAgent() {
    return __awaiter(this, void 0, void 0, function* () {
        const chat = (0, context_1.getChatContext)();
        const systemPrompt = `
You are the Reminder Agent in CodeA11y.
Review the chat history. If any manual implementation steps were suggested by the Responder Agent, remind the developer to complete them.
Be specific and concise.
  `.trim();
        const fullPrompt = `
[Chat History]
${chat}
  `.trim();
        const response = yield (0, api_1.callLLM)(systemPrompt, fullPrompt);
        (0, notifier_1.sendReminderNotification)(response);
        return response;
    });
}
