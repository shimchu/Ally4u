import { callLLM } from '../utils/api';
import { getChatContext } from '../utils/context';
import { sendReminderNotification } from '../utils/notifier';

export async function reminderAgent(): Promise<string> {
  const chat = getChatContext();

  const systemPrompt = `
You are the Reminder Agent in CodeA11y.
Review the chat history. If any manual implementation steps were suggested by the Responder Agent, remind the developer to complete them.
Be specific and concise.
  `.trim();

  const fullPrompt = `
[Chat History]
${chat}
  `.trim();

  const response = await callLLM(systemPrompt, fullPrompt);
  sendReminderNotification(response);
  return response;
}
