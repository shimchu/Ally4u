"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.correctionAgent = correctionAgent;
const api_1 = require("../utils/api");
const context_1 = require("../utils/context");
function correctionAgent() {
    return __awaiter(this, void 0, void 0, function* () {
        const logs = yield (0, context_1.getAccessibilityLogs)();
        const code = yield (0, context_1.getRelevantCodeContext)();
        const systemPrompt = `
You are the Correction Agent in CodeA11y.
Use Axe Linter logs and code to identify unresolved accessibility issues.
Suggest specific code changes or fixes to the developer.
  `.trim();
        const fullPrompt = `
[Accessibility Logs]
${logs}

[Relevant Code]
${code}
  `.trim();
        return yield (0, api_1.callLLM)(systemPrompt, fullPrompt);
    });
}
