import { callLLM } from '../utils/api';
import { getRelevantCodeContext, getAccessibilityLogs, getChatContext} from '../utils/context';

export async function responderAgent(userPrompt: string): Promise<string> {
  const code = await getRelevantCodeContext();
  const logs = await getAccessibilityLogs();
  const chat = getChatContext();

  const systemPrompt = `
You are CodeA11y's Responder Agent. The developer is likely unfamiliar with accessibility.
Use the user's prompt, code, logs, project info, and chat history to:
- Suggest improved code
- Explain accessibility fixes
- Follow WCAG 2.1 AA
- Be actionable and concise
  `.trim();

  const fullPrompt = `
[User Question]
${userPrompt}

[Code Context]
${code}

[Accessibility Logs]
${logs}

[Chat History]
${chat}
  `.trim();

  return await callLLM(systemPrompt, fullPrompt);
}
