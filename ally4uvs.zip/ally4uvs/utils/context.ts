import * as vscode from 'vscode';
import * as fs from 'fs/promises';
import { JSDOM } from 'jsdom';
import axe from 'axe-core';

let chatHistory: string[] = [];

export async function getRelevantCodeContext(): Promise<string> {
  const editor = vscode.window.activeTextEditor;
  if (!editor) return 'No active editor';
  const doc = editor.document;
  const cursorLine = editor.selection.active.line;

  const totalLines = doc.lineCount;
  const start = Math.max(0, cursorLine - 50);
  const end = Math.min(totalLines, cursorLine + 50);

  let code = '';
  for (let i = start; i < end; i++) {
    code += doc.lineAt(i).text + '\n';
  }

  return code.trim();
}

import * as path from 'path';
import puppeteer from 'puppeteer';
import axeSource from 'axe-core/axe.min.js';

export async function getAccessibilityLogs(): Promise<string> {
  try {
    // 1. Get 10 lines around cursor
    const editor = vscode.window.activeTextEditor;
    if (!editor) throw new Error('No active editor');

    const totalLines = editor.document.lineCount;
    const cursorLine = editor.selection.active.line;

    const startLine = Math.max(0, cursorLine - 5);
    const endLine = Math.min(totalLines - 1, cursorLine + 5);

    const range = new vscode.Range(
      startLine,
      0,
      endLine,
      editor.document.lineAt(endLine).text.length
    );
    const snippet = editor.document.getText(range);

    // 2. Wrap snippet in minimal HTML
    const html = `<!DOCTYPE html>
<html lang="en">
<head><title>A11y Test</title></head>
<body>
${snippet}
</body>
</html>`;

    // 3. Run axe-core in Puppeteer
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();

    await page.setContent(html, { waitUntil: 'load' });

    await page.evaluate((axeSrc:any) => {
      const script = document.createElement('script');
      script.text = axeSrc;
      document.head.appendChild(script);
    }, axeSource);

    const results = await page.evaluate(async () => {
      return await (window as any).axe.run();
    });

    await browser.close();

    const log = JSON.stringify(results, null, 2);

    // 4. Save to accessibility.log in workspace root
    const workspaceFolders = vscode.workspace.workspaceFolders;
    if (!workspaceFolders) throw new Error('No workspace folder found');
    const workspacePath = workspaceFolders[0].uri.fsPath;
    const logPath = path.join(workspacePath, 'accessibility.log');

    await fs.writeFile(logPath, log, 'utf8');

    // 5. Read back and return content
    const content = await fs.readFile(logPath, 'utf-8');
    return content;
  } catch (err) {
    return 'No accessibility logs found.';
  }
}


export function getChatContext(): string {
  return chatHistory.slice(-5).join('\n\n');
}

export function addToChatContext(user: string, assistant: string) {
  chatHistory.push(`User: ${user}\nAssistant: ${assistant}`);
}
