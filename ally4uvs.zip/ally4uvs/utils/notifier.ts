import * as vscode from 'vscode';

export function sendReminderNotification(message: string) {
  vscode.window.showWarningMessage(`Reminder from CodeA11y: ${message}`);
}
