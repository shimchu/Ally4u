import { OpenAI } from 'openai';

// Initialize OpenAI client with your hardcoded API key
const openai = new OpenAI({ apiKey: 'YOUR_HARDCODED_API_KEY' });

export async function callLLM(systemPrompt: string, userPrompt: string): Promise<string> {
  try {
    // Create a chat completion using the new API structure
    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: 0.3,
    });

    // Return the assistant's message content
    return response.choices[0]?.message.content ?? 'No response.';
  } catch (error) {
    console.error('Error calling LLM:', error);
    return 'An error occurred while fetching the response.';
  }
}
