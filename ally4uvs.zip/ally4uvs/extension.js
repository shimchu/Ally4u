import * as vscode from 'vscode';

import { responderAgent } from './agents/responder';
import { correctionAgent } from './agents/correction';
import { reminderAgent } from './agents/reminder';
import { generateAltSuggestion } from './agents/altgen';

import { addToChatContext } from './utils/context';

/**
 * This method is called when your extension is activated
 * @param context VSCode extension context
 */
export function activate(context: vscode.ExtensionContext) {
  context.subscriptions.push(
    vscode.commands.registerCommand('codea11y.runAgents', async () => {
      const prompt = await vscode.window.showInputBox({ prompt: 'Ask CodeA11y something...' });
      if (!prompt) return;

      // ALT TEXT GENERATION CHECK
      if (/suggest an alt text/i.test(prompt) && /(http[s]?:\/\/.*\.(?:png|jpg|jpeg|webp|gif|svg))/i.test(prompt)) {
        const imageUrl = prompt.match(/(http[s]?:\/\/.*\.(?:png|jpg|jpeg|webp|gif|svg))/i)?.[0];
        if (imageUrl) {
          const { altSuggestion, reminderNote } = await generateAltSuggestion(imageUrl, '');
          vscode.window.showInformationMessage(`Alt Text Suggestion: ${altSuggestion}`);
          vscode.window.showInformationMessage(`Reminder: ${reminderNote}`);
          return;
        }
      }

      // Run Responder Agent
      const responderReply = await responderAgent(prompt);
      vscode.window.showInformationMessage(`Responder: ${responderReply}`);

      // Run Correction Agent
      const correctionReply = await correctionAgent();
      vscode.window.showInformationMessage(`Correction: ${correctionReply}`);

      // Run Reminder Agent
      const reminderReply = await reminderAgent();
      vscode.window.showInformationMessage(`Reminder: ${reminderReply}`);

      // Update chat context with latest interaction
      addToChatContext(prompt, responderReply);
    })
  );
}

/**
 * This method is called when your extension is deactivated
 */
export function deactivate() {}
