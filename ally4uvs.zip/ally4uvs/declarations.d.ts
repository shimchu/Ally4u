declare module 'axe-core/axe.min.js';
